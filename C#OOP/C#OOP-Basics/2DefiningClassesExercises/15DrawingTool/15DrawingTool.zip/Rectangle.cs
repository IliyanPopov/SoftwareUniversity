﻿namespace _15DrawingTool
{
    public class Rectangle:Shape
    {

    }
}
﻿namespace _15DrawingTool
{
    public class Square : Shape
    {
    }
}
﻿namespace _15DrawingTool
{
    public class Shape
    {
        public virtual int SideX { get; set; }

        public virtual int SideY { get; set; }
    }
}
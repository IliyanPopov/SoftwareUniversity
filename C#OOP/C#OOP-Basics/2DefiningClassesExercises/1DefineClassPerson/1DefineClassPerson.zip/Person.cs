﻿namespace _1DefineClassPerson
{
    public class Person
    {
        public string name;

        public int age;
    }
}
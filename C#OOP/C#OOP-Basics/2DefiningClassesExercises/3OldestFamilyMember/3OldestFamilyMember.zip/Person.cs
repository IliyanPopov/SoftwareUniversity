﻿namespace _3OldestFamilyMember
{
    public class Person
    {
        public int age;
        public string name;
    }
}
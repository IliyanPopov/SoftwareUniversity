﻿namespace _14CatLady
{
    public abstract class Cat
    {
        public string Name { get; set; }

        public virtual string BreedName { get; set; }
    }
}
﻿public abstract class Felime : Mamal
{
    public Felime(string animalName, string animalType, double animalWeight, string livingRegion) : base(animalType, animalName, animalWeight, livingRegion)
    {
    }
}

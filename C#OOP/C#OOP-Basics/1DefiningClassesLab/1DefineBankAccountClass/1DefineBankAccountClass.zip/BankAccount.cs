public class BankAccount
{
    private double balance;
    private int id;

    public int ID { get; set; }


    public double Balance { get; set; }
}
﻿public class Happy : BaseMood
{
    private const string MoodName = "Happy";

    public override string Name
    {
        get { return MoodName; }
    }
}


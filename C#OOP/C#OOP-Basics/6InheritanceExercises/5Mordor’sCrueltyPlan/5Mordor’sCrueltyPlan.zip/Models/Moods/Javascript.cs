﻿public class Javascript : BaseMood
{
    private const string MoodName = "JavaScript";

    public override string Name
    {
        get { return MoodName; }
    }
}


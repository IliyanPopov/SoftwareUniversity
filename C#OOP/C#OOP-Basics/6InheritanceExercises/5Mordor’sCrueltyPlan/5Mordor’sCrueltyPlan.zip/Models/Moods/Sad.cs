﻿public class Sad : BaseMood
{
    private const string MoodName = "Sad";

    public override string Name
    {
        get { return MoodName; }
    }
}


﻿public abstract class BaseMood
{
    public virtual string Name { get; }
}


﻿public class Angry : BaseMood
{
    private const string MoodName = "Angry";

    public override string Name
    {
        get { return MoodName; }
    }
}


﻿public class Apple : Food
{

    private const int AppleDefaultPointsOfHappiness = 1;

    public override int PointsOfHappiness
    {
        get { return AppleDefaultPointsOfHappiness; }
    }
}


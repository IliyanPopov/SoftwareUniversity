﻿public class EverythingElse : Food
{
    private const int EverythingElseDefaultPointsOfHappiness = -1;

    public override int PointsOfHappiness
    {
        get { return EverythingElseDefaultPointsOfHappiness; }
    }
}


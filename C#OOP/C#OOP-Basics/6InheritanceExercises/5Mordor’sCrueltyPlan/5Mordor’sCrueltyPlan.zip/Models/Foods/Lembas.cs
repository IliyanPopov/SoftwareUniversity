﻿public class Lembas : Food
{
    private const int LembasDefaultPointsOfHappiness = 3;

    public override int PointsOfHappiness
    {
        get { return LembasDefaultPointsOfHappiness; }
    }
}


﻿public abstract class Food
{
    public virtual int PointsOfHappiness
    {
        get { return 0; }
    }
}


﻿using System;
using System.Text;

public class Worker : Human
{
   // private string _firstName;
    private double _weekSalary;
    private double _workHoursPerDay;

    public Worker(string firstName, string lastName, double weekSalary, double workingHoursPerDay) : base(firstName,
        lastName)
    {
        WeekSalary = weekSalary;
        WorkHoursPerDay = workingHoursPerDay;
    }

    public double WorkHoursPerDay
    {
        get { return _workHoursPerDay; }
        set
        {
            if (value < 1 || value > 12)
            {
                throw new ArgumentException("Expected value mismatch! Argument: workHoursPerDay");
            }

            _workHoursPerDay = value;
        }
    }

    public double WeekSalary
    {
        get { return _weekSalary; }
        set
        {
            if (value < 10)
            {
                throw new ArgumentException("Expected value mismatch! Argument: weekSalary");
            }
            _weekSalary = value;
        }
    }

    //public override string FirstName
    //{
    //    get { return _firstName; }
    //    set
    //    {
    //        if (value.Length < 3)
    //        {
    //            throw new ArgumentException("Expected length more than 3 symbols! Argument: lastName");
    //        }

    //        _firstName = value;
    //    }
    //}

    public double CalculateMoneyPerHour()
    {
        //  var daySalary = ;
        var moneyPerHour = (WeekSalary / 5) / WorkHoursPerDay;

        return moneyPerHour;
    }

    public override string ToString()
    {
        var sb = new StringBuilder();
        sb.AppendLine($"First Name: {FirstName}")
            .AppendLine($"Last Name: {LastName}")
            .AppendLine($"Week Salary: {WeekSalary:F2}")
            .AppendLine($"Hours per day: {WorkHoursPerDay:F2}")
            .AppendLine($"Salary per hour: {CalculateMoneyPerHour():F2}");

        return sb.ToString();
    }
}
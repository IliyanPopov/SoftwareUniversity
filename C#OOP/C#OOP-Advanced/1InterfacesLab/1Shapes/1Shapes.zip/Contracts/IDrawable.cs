﻿public interface IDrawable
{
    void Draw();
}


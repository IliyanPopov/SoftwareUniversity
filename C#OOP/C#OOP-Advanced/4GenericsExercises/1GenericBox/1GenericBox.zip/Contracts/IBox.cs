﻿public interface IBox<T>
{
    void Add(T t);
}


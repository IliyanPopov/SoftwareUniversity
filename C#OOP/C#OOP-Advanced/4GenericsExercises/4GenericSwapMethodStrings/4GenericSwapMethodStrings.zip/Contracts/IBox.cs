﻿public interface IBox<T>
{
    void Add(T t);

    void Swap(int index1, int index2);
}


﻿public interface IAttacker
{
    int AttackDamage { get; }
}
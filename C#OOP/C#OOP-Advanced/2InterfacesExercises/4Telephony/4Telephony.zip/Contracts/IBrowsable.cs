﻿using System;
using System.Collections.Generic;

public interface IBrowsable
{
    void Browse(string website);
}


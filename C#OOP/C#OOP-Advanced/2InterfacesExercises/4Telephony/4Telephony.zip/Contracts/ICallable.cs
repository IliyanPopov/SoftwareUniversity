﻿using System.Collections.Generic;

public interface ICallable
{
    void Call(string number);

}


using System.Collections.Generic;

public interface IEngineer
{
    IList<IRepair> Repairs { get; }
}
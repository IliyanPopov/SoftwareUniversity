﻿using System.Collections.Generic;

public interface ILeutenantGeneral
{
    IList<ISoldier> Privates { get;}
}
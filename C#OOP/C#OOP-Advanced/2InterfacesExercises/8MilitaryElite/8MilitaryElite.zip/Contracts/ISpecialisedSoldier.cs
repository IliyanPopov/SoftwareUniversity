﻿public interface ISpecialisedSoldier
{
    Corps Corps { get; }
}
﻿public interface ICitizen : IResident, IPerson
{
    int Age { get; }
}


﻿[SoftUni("Ilian")]
public class Startup
{
    [SoftUni("Ilian")]
    public static void Main()
    {
        Tracker.PrintMethodsByAuthor();
    }
}